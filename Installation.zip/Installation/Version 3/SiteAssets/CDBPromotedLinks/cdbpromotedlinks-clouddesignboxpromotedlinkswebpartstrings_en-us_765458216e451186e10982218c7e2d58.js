define([], function() {
  return {
    "PropertyPaneDescription": "Promoted Links Web Part by Cloud Design Box Ltd https://www.clouddesignbox.co.uk",
    "BasicGroupName": "List",
    "AdvancedGroupName": "Advanced Settings",
    "ImageLibraryFieldLabel": "Promoted Links List Name",
    "TileColour": "Tile Background Colour",
    "TileAnimation": "Hover Animation",
    "BackgroundSizeFieldLabel": "Background Image Size"
  }
});